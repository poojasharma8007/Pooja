const prompt = require('prompt-async');
const desktop_path = '/home/jc40';
const fs = require('fs');
const AdmZip = require('adm-zip');

startApp();

async function startApp() {
    prompt.start();
    
    const firstQues = "Please enter a folder name to create";
    let promptResult = await prompt.get(firstQues);
    const createFolder = promptResult[firstQues];
   
    fs.mkdirSync(desktop_path + '/' + createFolder);
    console.log("Folder created successfully");

    const secondQues = "Please enter a folder name to search";  
    let Result = await prompt.get(secondQues);
    const folderToSearch = Result[secondQues];

    const thirdQues = "Please enter a path name ";  
    promptResult = await prompt.get(thirdQues);
    let folderPath = promptResult[thirdQues];

    await createZip(folderPath + "/" + folderToSearch, desktop_path + "/" + createFolder + "/" + folderToSearch + ".zip");
}

 
function createZip(sourceFolder, zipFilePath) {
    console.log("zipping folder");
    return new Promise((resolve, reject) => {
        const zip = new AdmZip();
        
        // Add folder content to the zip
        zip.addLocalFolder(sourceFolder);

        // Write the zip file
        zip.writeZip(zipFilePath, err => {
            if (err) {
                reject(err);
            } 
            else {
                console.log('Zip file created successfully.');
                resolve();
            }
        });
    });
}

  
  
 
 